//Attach plugin to slideshow with ".gallery-slideshow" class
$(function() {
  $('.gallerys-slideshow').slideshow({
    interval: 10000,
    width: 660,
    height: 450
  });
});
